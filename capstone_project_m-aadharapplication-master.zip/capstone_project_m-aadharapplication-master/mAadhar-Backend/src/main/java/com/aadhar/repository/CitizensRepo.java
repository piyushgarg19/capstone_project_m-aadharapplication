package com.aadhar.repository;

import org.springframework.data.repository.CrudRepository;

import com.aadhar.entity.Citizens;

public interface CitizensRepo extends CrudRepository<Citizens, Integer> {

}
