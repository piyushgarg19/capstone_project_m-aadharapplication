package com.aadhar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MAadharBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MAadharBackendApplication.class, args);
	}

}
